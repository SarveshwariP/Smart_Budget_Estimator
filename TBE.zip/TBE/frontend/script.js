const API_URL = 'http://localhost:5000/api';

console.log('TripWise Frontend loaded');
console.log('API URL:', API_URL);

// DOM Elements
const tripForm = document.getElementById('tripForm');
const destinationInput = document.getElementById('destination');
const daysInput = document.getElementById('days');
const peopleInput = document.getElementById('people');
const budgetTypeInput = document.getElementById('budgetType');
const estimateBtn = document.getElementById('estimateBtn');

const formSection = document.getElementById('formSection');
const resultsSection = document.getElementById('resultsSection');
const errorSection = document.getElementById('errorSection');
const loadingSpinner = document.getElementById('loadingSpinner');

const hotelsList = document.getElementById('hotelsList');
const restaurantsList = document.getElementById('restaurantsList');
const transportDetails = document.getElementById('transportDetails');
const hotelCostEl = document.getElementById('hotelCost');
const foodCostEl = document.getElementById('foodCost');
const transportCostEl = document.getElementById('transportCost');
const totalCostEl = document.getElementById('totalCost');
const resultsSummary = document.getElementById('resultsSummary');

const newEstimateBtn = document.getElementById('newEstimateBtn');
const retryBtn = document.getElementById('retryBtn');
const errorMessage = document.getElementById('errorMessage');

// Event Listeners
if (tripForm) {
  tripForm.addEventListener('submit', handleFormSubmit);
  console.log('✅ Form listener attached');
}

if (newEstimateBtn) {
  newEstimateBtn.addEventListener('click', resetForm);
  console.log('✅ New estimate button listener attached');
}

if (retryBtn) {
  retryBtn.addEventListener('click', resetForm);
  console.log('✅ Retry button listener attached');
}

// Validation
function validateForm() {
  let isValid = true;
  clearErrors();

  if (!destinationInput.value) {
    showFieldError('destinationError', 'Please select a destination');
    isValid = false;
  }

  if (!daysInput.value || daysInput.value <= 0) {
    showFieldError('daysError', 'Please enter days (min 1)');
    isValid = false;
  }

  if (!peopleInput.value || peopleInput.value <= 0) {
    showFieldError('peopleError', 'Please enter people (min 1)');
    isValid = false;
  }

  if (!budgetTypeInput.value) {
    showFieldError('budgetTypeError', 'Please select budget type');
    isValid = false;
  }

  return isValid;
}

function showFieldError(elementId, message) {
  const el = document.getElementById(elementId);
  if (el) {
    el.textContent = message;
    el.classList.add('show');
  }
}

function clearErrors() {
  document.querySelectorAll('.error-message').forEach(el => {
    el.textContent = '';
    el.classList.remove('show');
  });
}

// Form Submission
async function handleFormSubmit(event) {
  event.preventDefault();
  console.log('Form submitted');

  if (!validateForm()) {
    console.log('Form validation failed');
    return;
  }

  showLoader();

  try {
    const tripData = {
      destination: destinationInput.value,
      days: parseInt(daysInput.value),
      people: parseInt(peopleInput.value),
      budgetType: budgetTypeInput.value
    };

    console.log('Sending request:', tripData);

    const response = await fetch(`${API_URL}/estimate-trip`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(tripData)
    });

    console.log('Response status:', response.status);

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || `HTTP ${response.status}`);
    }

    const data = await response.json();
    console.log('Response data:', data);

    if (data.success && data.data) {
      displayResults(data.data, tripData);
    } else {
      throw new Error('Invalid response format');
    }

  } catch (error) {
    console.error('Error:', error);
    showError(error.message || 'Something went wrong. Please try again.');
  } finally {
    hideLoader();
  }
}

// Display Results
function displayResults(estimateData, tripData) {
  console.log('Displaying results');

  resultsSummary.textContent = 
    `${tripData.people} people in ${estimateData.destination} for ${tripData.days} days (${tripData.budgetType} budget)`;

  // Hotels
  hotelsList.innerHTML = '';
  if (estimateData.hotels && estimateData.hotels.length > 0) {
    estimateData.hotels.forEach(hotel => {
      const price = hotel.pricePerNight || hotel.price_per_night;
      hotelsList.innerHTML += `
        <div class="item">
          <div class="item-name">${hotel.name}</div>
          <div class="item-price">₹${price.toLocaleString()} / night</div>
        </div>
      `;
    });
  } else {
    hotelsList.innerHTML = '<p style="color: #636E72;">No hotels found</p>';
  }

  // Restaurants
  restaurantsList.innerHTML = '';
  if (estimateData.restaurants && estimateData.restaurants.length > 0) {
    estimateData.restaurants.forEach(rest => {
      const price = rest.avgMealPrice || rest.avg_meal_price;
      restaurantsList.innerHTML += `
        <div class="item">
          <div class="item-name">${rest.name}</div>
          <div class="item-price">₹${price.toLocaleString()} / meal</div>
        </div>
      `;
    });
  } else {
    restaurantsList.innerHTML = '<p style="color: #636E72;">No restaurants found</p>';
  }

  // Transport
  transportDetails.innerHTML = '';
  if (estimateData.transport) {
    const cost = estimateData.transport.estimatedCost || estimateData.transport.estimated_cost;
    transportDetails.innerHTML = `
      <div class="item">
        <div class="item-name">${estimateData.transport.type || 'Local Transport'}</div>
        <div class="item-price">₹${cost.toLocaleString()} / day</div>
      </div>
    `;
  }

  // Calculate costs
  const costs = calculateCosts(estimateData, tripData);
  displayCosts(costs);

  // Show results section
  formSection.style.display = 'none';
  errorSection.style.display = 'none';
  resultsSection.style.display = 'block';

  resultsSection.scrollIntoView({ behavior: 'smooth' });
  console.log('Results displayed successfully');
}

// Cost Calculation
function calculateCosts(estimateData, tripData) {
  const hotelPrice = estimateData.hotels && estimateData.hotels[0] 
    ? (estimateData.hotels[0].pricePerNight || estimateData.hotels[0].price_per_night)
    : 0;
  
  const mealPrice = estimateData.restaurants && estimateData.restaurants[0]
    ? (estimateData.restaurants[0].avgMealPrice || estimateData.restaurants[0].avg_meal_price)
    : 0;
  
  const transportCost = estimateData.transport 
    ? (estimateData.transport.estimatedCost || estimateData.transport.estimated_cost)
    : 0;

  const hotelTotal = hotelPrice * tripData.days;
  const foodTotal = mealPrice * tripData.days * tripData.people * 3;
  const transportTotal = transportCost * tripData.days;
  const grandTotal = hotelTotal + foodTotal + transportTotal;

  console.log('Calculated costs:', { hotelTotal, foodTotal, transportTotal, grandTotal });

  return {
    hotelTotal: Math.round(hotelTotal),
    foodTotal: Math.round(foodTotal),
    transportTotal: Math.round(transportTotal),
    grandTotal: Math.round(grandTotal)
  };
}

function displayCosts(costs) {
  hotelCostEl.textContent = `₹${costs.hotelTotal.toLocaleString()}`;
  foodCostEl.textContent = `₹${costs.foodTotal.toLocaleString()}`;
  transportCostEl.textContent = `₹${costs.transportTotal.toLocaleString()}`;
  totalCostEl.textContent = `₹${costs.grandTotal.toLocaleString()}`;
}

// UI Helpers
function showLoader() {
  loadingSpinner.classList.add('show');
  estimateBtn.disabled = true;
}

function hideLoader() {
  loadingSpinner.classList.remove('show');
  estimateBtn.disabled = false;
}

function showError(message) {
  console.log('Showing error:', message);
  errorMessage.textContent = message;
  formSection.style.display = 'none';
  resultsSection.style.display = 'none';
  errorSection.style.display = 'block';
  errorSection.scrollIntoView({ behavior: 'smooth' });
}

function resetForm() {
  console.log('Resetting form');
  tripForm.reset();
  clearErrors();
  formSection.style.display = 'block';
  resultsSection.style.display = 'none';
  errorSection.style.display = 'none';
  formSection.scrollIntoView({ behavior: 'smooth' });
}

console.log('✅ TripWise Frontend initialized successfully');