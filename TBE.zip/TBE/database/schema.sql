-- ============================================
-- TRIPWISE DATABASE SCHEMA
-- ============================================

-- Drop tables if they exist (for fresh start)
DROP TABLE IF EXISTS transport CASCADE;
DROP TABLE IF EXISTS restaurants CASCADE;
DROP TABLE IF EXISTS hotels CASCADE;
DROP TABLE IF EXISTS destinations CASCADE;

-- ============================================
-- DESTINATIONS TABLE
-- ============================================

CREATE TABLE destinations (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    state VARCHAR(100),
    best_season VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- HOTELS TABLE
-- ============================================

CREATE TABLE hotels (
    id SERIAL PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    destination VARCHAR(100) NOT NULL,
    price_per_night DECIMAL(10, 2) NOT NULL,
    budget_type VARCHAR(20) NOT NULL,
    rating DECIMAL(3, 1),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- RESTAURANTS TABLE
-- ============================================

CREATE TABLE restaurants (
    id SERIAL PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    destination VARCHAR(100) NOT NULL,
    avg_meal_price DECIMAL(10, 2) NOT NULL,
    budget_type VARCHAR(20) NOT NULL,
    cuisine_type VARCHAR(50),
    rating DECIMAL(3, 1),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- TRANSPORT TABLE
-- ============================================

CREATE TABLE transport (
    id SERIAL PRIMARY KEY,
    destination VARCHAR(100) NOT NULL,
    type VARCHAR(100),
    estimated_cost DECIMAL(10, 2) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- CREATE INDEXES
-- ============================================

CREATE INDEX idx_hotels_destination ON hotels(destination);
CREATE INDEX idx_hotels_budget ON hotels(budget_type);
CREATE INDEX idx_restaurants_destination ON restaurants(destination);
CREATE INDEX idx_restaurants_budget ON restaurants(budget_type);
CREATE INDEX idx_transport_destination ON transport(destination);

-- ============================================
-- INSERT DESTINATIONS
-- ============================================

INSERT INTO destinations (name, description, state, best_season) VALUES
('Goa', 'Beautiful beaches and Portuguese architecture', 'Goa', 'November to March'),
('Ooty', 'Hill station with lush greenery', 'Tamil Nadu', 'June to October'),
('Chennai', 'Coastal city with temples', 'Tamil Nadu', 'November to February'),
('Bangalore', 'Modern city with IT industry', 'Karnataka', 'October to February');

-- ============================================
-- INSERT HOTELS - GOA
-- ============================================

INSERT INTO hotels (name, destination, price_per_night, budget_type, rating, address) VALUES
('Budget Beach Hut', 'Goa', 800, 'low', 3.5, 'Calangute Beach'),
('Sea View Lodge', 'Goa', 2000, 'medium', 4.0, 'Baga Beach'),
('Tropical Escape', 'Goa', 3500, 'medium', 4.2, 'Anjuna Beach'),
('Sunset Palace', 'Goa', 6000, 'luxury', 4.7, 'North Goa'),
('Pearl Beach Resort', 'Goa', 8000, 'luxury', 4.8, 'Candolim Beach');

-- ============================================
-- INSERT HOTELS - OOTY
-- ============================================

INSERT INTO hotels (name, destination, price_per_night, budget_type, rating, address) VALUES
('Hill Hostel', 'Ooty', 600, 'low', 3.4, 'Market Road'),
('Green Valley Hotel', 'Ooty', 1800, 'medium', 4.0, 'Lake Road'),
('Mountain View Resort', 'Ooty', 2800, 'medium', 4.1, 'Coonoor Road'),
('The Nilgiri Palace', 'Ooty', 5000, 'luxury', 4.6, 'Pykara Road'),
('Monarch Heights', 'Ooty', 7000, 'luxury', 4.8, 'Upper Lake Road');

-- ============================================
-- INSERT HOTELS - CHENNAI
-- ============================================

INSERT INTO hotels (name, destination, price_per_night, budget_type, rating, address) VALUES
('Budget Inn', 'Chennai', 700, 'low', 3.3, 'Egmore'),
('Marina View Hotel', 'Chennai', 1900, 'medium', 4.0, 'Marina Beach'),
('Coastal Comfort', 'Chennai', 2900, 'medium', 4.1, 'OMR Road'),
('The Grand Chennai', 'Chennai', 5500, 'luxury', 4.7, 'Teynampet'),
('Luxury Harbor Hotel', 'Chennai', 7500, 'luxury', 4.9, 'Downtown');

-- ============================================
-- INSERT HOTELS - BANGALORE
-- ============================================

INSERT INTO hotels (name, destination, price_per_night, budget_type, rating, address) VALUES
('Tech Stay Hostel', 'Bangalore', 750, 'low', 3.5, 'Indiranagar'),
('Corporate Hotel', 'Bangalore', 2000, 'medium', 4.0, 'Whitefield'),
('Business Park Resort', 'Bangalore', 3000, 'medium', 4.1, 'Koramangala'),
('Tech Palace Hotel', 'Bangalore', 5200, 'luxury', 4.7, 'MG Road'),
('Innovation Luxury', 'Bangalore', 7800, 'luxury', 4.9, 'Bandra');

-- ============================================
-- INSERT RESTAURANTS - GOA
-- ============================================

INSERT INTO restaurants (name, destination, avg_meal_price, budget_type, cuisine_type, rating) VALUES
('Street Bites', 'Goa', 200, 'low', 'Local', 3.5),
('Coconut Curry', 'Goa', 400, 'medium', 'Indian', 4.0),
('Spice Garden', 'Goa', 600, 'medium', 'Seafood', 4.2),
('Beachfront Dining', 'Goa', 1000, 'luxury', 'Continental', 4.7),
('The Portuguese House', 'Goa', 1500, 'luxury', 'Fusion', 4.9);

-- ============================================
-- INSERT RESTAURANTS - OOTY
-- ============================================

INSERT INTO restaurants (name, destination, avg_meal_price, budget_type, cuisine_type, rating) VALUES
('Local Taste', 'Ooty', 180, 'low', 'South Indian', 3.5),
('Tea House Café', 'Ooty', 350, 'medium', 'Continental', 4.0),
('Hill Station Kitchen', 'Ooty', 550, 'medium', 'Indian', 4.1),
('Alpine Dining', 'Ooty', 900, 'luxury', 'Multi-cuisine', 4.6),
('Summit Restaurant', 'Ooty', 1200, 'luxury', 'International', 4.8);

-- ============================================
-- INSERT RESTAURANTS - CHENNAI
-- ============================================

INSERT INTO restaurants (name, destination, avg_meal_price, budget_type, cuisine_type, rating) VALUES
('Dosa Street', 'Chennai', 150, 'low', 'South Indian', 3.6),
('Fish Market', 'Chennai', 380, 'medium', 'Seafood', 4.0),
('Spice Route', 'Chennai', 600, 'medium', 'Indian', 4.2),
('Seaside Fine Dining', 'Chennai', 1100, 'luxury', 'Continental', 4.6),
('The Coastal Kitchen', 'Chennai', 1600, 'luxury', 'International', 4.8);

-- ============================================
-- INSERT RESTAURANTS - BANGALORE
-- ============================================

INSERT INTO restaurants (name, destination, avg_meal_price, budget_type, cuisine_type, rating) VALUES
('Street Food Hub', 'Bangalore', 200, 'low', 'South Indian', 3.7),
('Fusion Corner', 'Bangalore', 400, 'medium', 'Multi-cuisine', 4.0),
('Tech Cafe', 'Bangalore', 650, 'medium', 'Continental', 4.2),
('The Startup Kitchen', 'Bangalore', 1050, 'luxury', 'International', 4.7),
('Silicon Valley Bistro', 'Bangalore', 1700, 'luxury', 'Fine Dining', 4.9);

-- ============================================
-- INSERT TRANSPORT
-- ============================================

INSERT INTO transport (destination, type, estimated_cost, description) VALUES
('Goa', 'Local Transport', 500, 'Taxis, autos, bike rentals'),
('Ooty', 'Local Transport', 400, 'Autos, taxis, cable cars'),
('Chennai', 'Local Transport', 450, 'Metro, buses, taxis'),
('Bangalore', 'Local Transport', 550, 'Metro, autos, cab services');