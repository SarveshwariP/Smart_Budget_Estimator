# 🧳 TripWise - Smart Trip Cost Estimator & Planner

Full-stack web application for trip cost estimation and planning.

## ✨ Features

- ✅ Estimate trip costs based on destination, days, people, and budget
- ✅ Hotel recommendations with pricing
- ✅ Restaurant suggestions with meal costs
- ✅ Transport cost calculation
- ✅ Responsive mobile-friendly design
- ✅ Clean and modern UI

## 🏗️ Tech Stack

- **Frontend**: HTML5, CSS3, JavaScript
- **Backend**: Node.js, Express.js
- **Database**: PostgreSQL
- **Deployment**: Render + Neon

## 📦 Project Structure
