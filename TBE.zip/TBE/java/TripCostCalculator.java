package java;
public class TripCostCalculator {
    private static final double LOW_BUDGET_MULTIPLIER = 1.0;
    private static final double MEDIUM_BUDGET_MULTIPLIER = 1.5;
    private static final double LUXURY_BUDGET_MULTIPLIER = 2.5;

    private static final int GROUP_DISCOUNT_THRESHOLD = 5;
    private static final double GROUP_DISCOUNT_RATE = 0.10;

    public static double calculateHotelCost(
            double hotelPricePerNight,
            int numberOfDays,
            int numberOfPeople,
            String budgetType) {

        double adjustedPrice = applyBudgetMultiplier(hotelPricePerNight, budgetType);
        double baseCost = adjustedPrice * numberOfDays;

        if (numberOfPeople >= GROUP_DISCOUNT_THRESHOLD) {
            baseCost = baseCost * (1 - GROUP_DISCOUNT_RATE);
        }

        return Math.round(baseCost * 100.0) / 100.0;
    }

    public static double calculateFoodCost(
            double avgMealPrice,
            int numberOfDays,
            int numberOfPeople,
            String budgetType,
            int mealsPerDay) {

        double adjustedPrice = applyBudgetMultiplier(avgMealPrice, budgetType);
        double totalCost = adjustedPrice * numberOfDays * numberOfPeople * mealsPerDay;

        return Math.round(totalCost * 100.0) / 100.0;
    }

    public static double calculateTransportCost(
            double estimatedCostPerDay,
            int numberOfDays,
            int numberOfPeople) {

        double totalCost = estimatedCostPerDay * numberOfDays * numberOfPeople;

        if (numberOfPeople >= GROUP_DISCOUNT_THRESHOLD) {
            totalCost = totalCost * (1 - GROUP_DISCOUNT_RATE);
        }

        return Math.round(totalCost * 100.0) / 100.0;
    }

    public static double calculateTotalCost(
            double hotelCost,
            double foodCost,
            double transportCost,
            double contingency) {

        double subtotal = hotelCost + foodCost + transportCost;
        double contingencyAmount = subtotal * (contingency / 100.0);
        double total = subtotal + contingencyAmount;

        return Math.round(total * 100.0) / 100.0;
    }

    private static double applyBudgetMultiplier(double basePrice, String budgetType) {
        switch (budgetType.toLowerCase()) {
            case "low":
                return basePrice * LOW_BUDGET_MULTIPLIER;
            case "medium":
                return basePrice * MEDIUM_BUDGET_MULTIPLIER;
            case "luxury":
                return basePrice * LUXURY_BUDGET_MULTIPLIER;
            default:
                return basePrice;
        }
    }

    public static double calculateCostPerPerson(double totalCost, int numberOfPeople) {
        if (numberOfPeople <= 0) {
            return 0;
        }
        return Math.round((totalCost / numberOfPeople) * 100.0) / 100.0;
    }

    public static double calculateGroupDiscount(int numberOfPeople) {
        if (numberOfPeople >= GROUP_DISCOUNT_THRESHOLD) {
            return GROUP_DISCOUNT_RATE;
        }
        return 0;
    }

    public static void main(String[] args) {
        double hotelCost = calculateHotelCost(2000, 3, 2, "medium");
        double foodCost = calculateFoodCost(400, 3, 2, "medium", 3);
        double transportCost = calculateTransportCost(500, 3, 2);
        double totalCost = calculateTotalCost(hotelCost, foodCost, transportCost, 10);

        System.out.println("============ TRIP COST ESTIMATE ============");
        System.out.println("Hotel Cost: ₹" + hotelCost);
        System.out.println("Food Cost: ₹" + foodCost);
        System.out.println("Transport Cost: ₹" + transportCost);
        System.out.println("Total Cost: ₹" + totalCost);
        System.out.println("Cost per Person: ₹" + calculateCostPerPerson(totalCost, 2));
        System.out.println("=========================================");
    }
}