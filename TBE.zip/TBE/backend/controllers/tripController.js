const db = require('../db');

// Get all destinations
exports.getDestinations = async (req, res) => {
  try {
    console.log('Fetching destinations...');
    const result = await db.query('SELECT * FROM destinations ORDER BY name');
    console.log(`Found ${result.rows.length} destinations`);
    
    res.json({ 
      success: true, 
      data: result.rows 
    });
  } catch (error) {
    console.error('Error fetching destinations:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch destinations',
      error: error.message
    });
  }
};

// Get hotels by destination
exports.getHotels = async (req, res) => {
  try {
    const { destination } = req.params;
    console.log(`Fetching hotels for: ${destination}`);
    
    if (!destination) {
      return res.status(400).json({ 
        success: false, 
        message: 'Destination is required' 
      });
    }

    const result = await db.query(
      'SELECT * FROM hotels WHERE LOWER(destination) = LOWER($1) ORDER BY price_per_night ASC',
      [destination]
    );
    
    console.log(`Found ${result.rows.length} hotels for ${destination}`);
    
    res.json({ 
      success: true, 
      data: result.rows 
    });
  } catch (error) {
    console.error('Error fetching hotels:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch hotels',
      error: error.message
    });
  }
};

// Get restaurants by destination
exports.getRestaurants = async (req, res) => {
  try {
    const { destination } = req.params;
    console.log(`Fetching restaurants for: ${destination}`);
    
    if (!destination) {
      return res.status(400).json({ 
        success: false, 
        message: 'Destination is required' 
      });
    }

    const result = await db.query(
      'SELECT * FROM restaurants WHERE LOWER(destination) = LOWER($1) ORDER BY avg_meal_price ASC',
      [destination]
    );
    
    console.log(`Found ${result.rows.length} restaurants for ${destination}`);
    
    res.json({ 
      success: true, 
      data: result.rows 
    });
  } catch (error) {
    console.error('Error fetching restaurants:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch restaurants',
      error: error.message
    });
  }
};

// Main: Estimate trip cost
exports.estimateTrip = async (req, res) => {
  try {
    const { destination, days, people, budgetType } = req.body;

    console.log('Estimate request:', { destination, days, people, budgetType });

    // Validation
    if (!destination || !days || !people || !budgetType) {
      return res.status(400).json({ 
        success: false, 
        message: 'All fields (destination, days, people, budgetType) are required' 
      });
    }

    if (days <= 0 || people <= 0) {
      return res.status(400).json({ 
        success: false, 
        message: 'Days and people must be greater than 0' 
      });
    }

    if (!['low', 'medium', 'luxury'].includes(budgetType)) {
      return res.status(400).json({ 
        success: false, 
        message: 'Budget type must be: low, medium, or luxury' 
      });
    }

    console.log(`Processing estimate for: ${destination}, ${days}d, ${people}p, ${budgetType}`);

    // Get hotels
    const hotelsResult = await db.query(
      `SELECT id, name, price_per_night as "pricePerNight", budget_type as "budgetType"
       FROM hotels 
       WHERE LOWER(destination) = LOWER($1) 
       AND budget_type = $2 
       LIMIT 5`,
      [destination, budgetType]
    );

    console.log(`Hotels found: ${hotelsResult.rows.length}`);

    // Get restaurants
    const restaurantsResult = await db.query(
      `SELECT id, name, avg_meal_price as "avgMealPrice", budget_type as "budgetType"
       FROM restaurants 
       WHERE LOWER(destination) = LOWER($1) 
       AND budget_type = $2 
       LIMIT 5`,
      [destination, budgetType]
    );

    console.log(`Restaurants found: ${restaurantsResult.rows.length}`);

    // Get transport
    const transportResult = await db.query(
      `SELECT id, type, estimated_cost as "estimatedCost"
       FROM transport 
       WHERE LOWER(destination) = LOWER($1) 
       LIMIT 1`,
      [destination]
    );

    console.log(`Transport found: ${transportResult.rows.length}`);

    // Check if data exists
    if (hotelsResult.rows.length === 0 && restaurantsResult.rows.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: `No data available for destination: ${destination}` 
      });
    }

    // Prepare response
    const response = {
      success: true,
      data: {
        destination,
        days: parseInt(days),
        people: parseInt(people),
        budgetType,
        hotels: hotelsResult.rows,
        restaurants: restaurantsResult.rows,
        transport: transportResult.rows[0] || {
          type: 'Local Transport',
          estimatedCost: 500
        }
      }
    };

    console.log('Sending response:', response);
    res.json(response);

  } catch (error) {
    console.error('Estimation error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to estimate trip cost',
      error: error.message
    });
  }
};