const express = require('express');
const router = express.Router();

console.log('Loading tripController...');
const tripController = require('../controllers/tripController');

// API Routes
router.post('/estimate-trip', (req, res, next) => {
  console.log('POST /api/estimate-trip called');
  console.log('Request body:', req.body);
  tripController.estimateTrip(req, res, next);
});

router.get('/destinations', (req, res, next) => {
  console.log('GET /api/destinations called');
  tripController.getDestinations(req, res, next);
});

router.get('/hotels/:destination', (req, res, next) => {
  console.log(`GET /api/hotels/${req.params.destination} called`);
  tripController.getHotels(req, res, next);
});

router.get('/restaurants/:destination', (req, res, next) => {
  console.log(`GET /api/restaurants/${req.params.destination} called`);
  tripController.getRestaurants(req, res, next);
});

module.exports = router;